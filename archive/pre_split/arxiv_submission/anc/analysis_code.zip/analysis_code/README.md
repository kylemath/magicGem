Ancillary code for "Magic Gems: Magic Squares as Orthogonality Conditions on a Height Function" (arXiv 2512.09170, v5).

src/        core helpers (magic square generation, gem coordinates, convex hull).
            NOTE: src/analysis.py contains the v4 energies for reference; the v5 paper uses the
            symmetric E_full defined in revision/theory/verify_theory.py.
revision/theory/        verify_theory.py  -- exact checks of every identity in Section 4 (python3 verify_theory.py)
revision/random_energy/ theory.py, exhaustive_n3.py, mc.py, algorithms.py, make_figure.py -- Section 5.2, 6.3
revision/lowmode_n4/    lowmode_enum.c (meet-in-the-middle), run_all.sh -- Section 5.4 (bash run_all.sh)
revision/gem_geometry/  run_geometry_880.py, siamese_proof.py, run_swaps_siamese.py -- Sections 5.3, 5.5, 5.6
magic_squares_880.npy   the 880 essentially different 4x4 magic squares (shape 880x4x4). Scripts expect it at
                        ../../data/magic_squares_880 (1).npy relative to Analysis/; adjust the path or symlink.
Requirements: Python 3.9+, numpy, scipy, matplotlib; a C compiler for lowmode_enum.c.
